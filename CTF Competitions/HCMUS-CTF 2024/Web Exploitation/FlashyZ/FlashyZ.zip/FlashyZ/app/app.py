import logging
import os
import subprocess
import uuid
import zipfile

from flask import (
    Flask,
    abort,
    flash,
    redirect,
    render_template,
    request,
    send_from_directory,
)

app = Flask(__name__)
UPLOAD_DIR = "/tmp"

app.config["MAX_CONTENT_LENGTH"] = 1 * 10**6  # 1 MB
app.config["SECRET_KEY"] = os.urandom(32)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():
    if "file" not in request.files:
        flash("No file uploaded", "danger")
        return render_template("index.html")

    file = request.files["file"]
    if file.filename.split(".")[-1].lower() != "zip":
        flash("Invalid extension", "danger")
        return render_template("index.html")

    the_zip_file = zipfile.ZipFile(file)
    if the_zip_file.testzip() is not None:
        flash("Invalid file", "danger")
        return render_template("index.html")
    
    file.stream.seek(0)
    upload_uuid = str(uuid.uuid4())
    filename = f"{UPLOAD_DIR}/zips/{upload_uuid}.zip"
    file.save(filename)
    subprocess.call(["unzip", filename, "-d", f"{UPLOAD_DIR}/out/{upload_uuid}"])
    flash(
        f'Your file is at <a href="/list/{upload_uuid}">{upload_uuid}</a>!', "success"
    )
    return redirect("/")


@app.route("/list/<string:path>")
def list(path):
    try:
        file_list = os.listdir(os.path.join(f"{UPLOAD_DIR}/out", os.path.basename(path)))
        return render_template('list.html', file_list=file_list, path=path)
    except:
        abort(404)

@app.route("/view/<string:path>/<string:filename>")
def view(path, filename):
    try:
        file_path = os.path.join(f"{UPLOAD_DIR}/out", os.path.basename(path))
        content = open(f"{file_path}/{os.path.basename(filename)}").read()
        return content
    except:
        abort(404)

@app.errorhandler(404)
def page_not_found(error):
    return render_template("404.html")


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
