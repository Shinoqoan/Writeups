from flask import Flask, request, render_template
import requests

app = Flask(__name__)

SEARCH_ENGINES = {
    "https://www.google.com/": "search",
    "https://www.bing.com/": "search",
    "https://html.duckduckgo.com/": "html",
    "https://search.yahoo.com/": "search",
    "https://search.brave.com/": "search"
}
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0"
FLAG = "HCMUS-CTF{Fake-flag}"

@app.route('/', methods=['GET'])
def index():
    return render_template("index.html", SEARCH_ENGINES=SEARCH_ENGINES)

@app.route('/surf', methods=['POST'])
def surf():
    try:
        search_engine = request.form.get('search_engine', '').strip()
        path = request.form.get('path', '').strip() or SEARCH_ENGINES[search_engine]
        query = request.form.get('q', '').strip()
        
        if search_engine not in SEARCH_ENGINES:
            return "Invalid data"
        if not search_engine or not query:
            return 'Invalid data'
        if not path and SEARCH_ENGINES[search_engine] != path:
            return 'Invalid data'
        res = requests.get(search_engine + path + '?q=' + query, headers={'User-Agent': UA})
        if res.status_code != 200:
            return 'Can\'t surf the web.'
        return res.text
    except requests.exceptions.RequestException as e:
        return 'Can\'t surf the web.'
    
@app.route('/flag',methods=['GET'])
def get_flag():
    user_ip = request.remote_addr
    if user_ip == "127.0.0.1":
        return FLAG
    else:
        return "Noper"

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0',port=4000)
